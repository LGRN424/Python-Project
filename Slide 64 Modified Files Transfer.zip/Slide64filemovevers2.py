import glob, os, shutil,sys
from time import time
from datetime import date
from os import path

source_dir = 'C:\Python27\Folder A'
dest_dir = 'C:\Python27\Folder B'

def mins_since_mod(file_):
    """Time from last modification in minutes"""
    return (time() - os.path.getmtime(file_)) / 60

    

print  "Files Modified during the last 24 hours:"
print
files = glob.iglob(os.path.join(source_dir, "*.txt"))
for file_ in files:
    if os.path.isfile(file_) and mins_since_mod(file_) < 1440:
        shutil.move(file_, dest_dir)
        print (file_)
        
        
