import shutil
import os
from tkinter import *
import tkinter.filedialog as fdialog
from time import time
import datetime
from os import path
import glob

class MainClass():

    def __init__(self,master):
        self.parent=master
        self.gui()
    
    def gui(self):
        self.Source=StringVar()
        self.Destination=StringVar()


        label=Label(root, text='The File Mover App', fg='Blue').grid(row=1,column=2)
        MySource=Entry(root, textvariable=self.Source).grid(row=9, column=2)
        browse=Button(root,text="Browse",command=lambda:self.Source.set(fdialog.askdirectory())).grid(row=9, column=3)
        MyDestination=Entry(root, textvariable=self.Destination).grid(row=10, column=2)
        browse1=Button(root,text="Browse",command=lambda:self.Destination.set(fdialog.askdirectory())).grid(row=10, column=3)
        
        button1=Button(root, text="  Move  ", command=self.move).grid(row=11, column=2)


    def move(self):
        src = self.Source.get()
       
        for file_ in os.listdir(src):
            
            src_file = os.path.join(src, file_)
            dst_file = os.path.join(self.Destination.get(),file_)
            if (file_.endswith(".txt")):
                shutil.move(src_file,dst_file)
                print (file_, "moved to", dst_file)

        

           
if __name__ == '__main__':
    root=Tk()
    app=MainClass(root)
    root.geometry("400x200+100+200")
    root.title('Move files')
    root.mainloop()
